// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>

//TEDDIE - add needed includes

//TEDDIE - Inlcude exception for the exception throw - https://www.cplusplus.com/doc/tutorial/exceptions/
#include <exception>
//TEDDIE - Include string for string variable type
#include <string>

//TEDDIE - Create a class for the Custom Exceptionfrom std::exceptions
struct TeddieException : public std::exception {
    //TEDDIE - virtual const for what and throw
    const char* what() const throw() {
        //TEDDIE - Customer error throw message
        return "A Big Exception Error Fish :( \n - Teddie says great catch though!";
    }
};

bool do_even_more_custom_application_logic()
{
    // TODO: Throw any standard exception

    //TEDDIE - Throw an overflow error
    throw std::overflow_error("that there's been overflow!");
    
    std::cout << "Running Even More Custom Application Logic." << std::endl;
    return true;
}

void do_custom_application_logic()
{
    // TODO: Wrap the call to do_even_more_custom_application_logic()
    //  with an exception handler that catches std::exception, displays
    //  a message and the exception.what(), then continues processing
    std::cout << "Running Custom Application Logic." << std::endl;

    //TEDDIE - Use TRY/CATCH/THROW
   
    //TEDDIE - Set up a TRY 
    try {
        //TEDDIE - IF custom logic succeeds
        if (do_even_more_custom_application_logic())
        {
            //TEDDIE - Print custom logic message
            std::cout << "Neat! Even More Custom Application Logic Succeeded!" << std::endl;
        }

    }

    //TEDDIE - Set up CATCH
    //TEDDIE - Test if overlow error is caught in the custom logic
    catch (std::overflow_error& e) {
        //TEDDIE - Print the error message
        std::cout << "Custom Application Logic Has Caught..." << e.what() << std::endl;
    }
    

    // TODO: Throw a custom exception derived from std::exception
    //  and catch it explictly in main
    
    //TEDDIE - Set up THROW
    //TEDDIE - Throw custom exception
    throw TeddieException();
        //TEDDIE - Print message - edited for fun
        std::cout << "Time to EXIT Custom Application Logic. Peace Out Cub Scout!" << std::_Unlock_shared_ptr_spin_lock;
}

float divide(float num, float den)
{
    // TODO: Throw an exception to deal with divide by zero errors using
    //  a standard C++ defined exception

    //TEDDIE - Divide by zero logic
    //TEDDIE - IF divide by zero
    if (den == 0) {
        //TEDDIE - Throw custom error message
        throw std::runtime_error("Don't you know you can't divide by zero! You've caused a Runtime Error!");
    }
    return (num / den);
}

void do_division() noexcept
{
    //  TODO: create an exception handler to capture ONLY the exception thrown
    //  by divide.

    float numerator = 10.0f;
    float denominator = 0;

    //TEDDIE - Set up a TRY/CATCH to capture the errors thrown by divide

    //TEDDIE - Set up TRY
    try {
        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }
    //TEDDIE - Set up CATCH
    catch (std::runtime_error& e) {
        //TEDDIE - Print error message
        std::cout << "Division Error Caught... " << e.what() << std::endl;
    }
}

int main()
{
    std::cout << "Exceptions Tests!" << std::endl;

    // TODO: Create exception handlers that catch (in this order):
    //  your custom exception
    //  std::exception
    //  uncaught exception 
    //  that wraps the whole main function, and displays a message to the console.

    //TEDDIE - Set up TRY/CATCH handlers

    //TEDDIE - Set up TRY
    try {
        //TEDDIE - Print exception test for division
        std::cout << "Exceptions Testing Now..." << std::endl;
        //TEDDIE - do_division try
        do_division();
        //TEDDIE - do_cusom_application_logic try
        do_custom_application_logic();
    }

    //TEDDIE - Set up CATCHes in order

    //TEDDIE - CATCH custom exception
    catch (const TeddieException& e)
    {
        std::cerr << "Look what main caught... " << e.what() << std::endl;
    }


    //TEDDIE - CATCH std::exception
    catch (const std::exception& e)
    {
        std::cerr << "Look what main caught... " << e.what() << std::endl;
    }

    //TEDDIE - CATCH uncaught exception
    catch (...)
    {
    }
}


// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu